const GOOGLE_API_KEY = "AIzaSyB03gwU5Q2hoCX7qmCo-HEtIvzmZTqwSQc"

export default GOOGLE_API_KEY