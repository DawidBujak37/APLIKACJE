# Skład Zespółu: Wojciech Kozioł, Dawid Bujak, Konrad Jaszczyk
# AM-PRO
# Przedmiot: Aplikacje Mobline 1
# Temat - Aplikacja do zamawiania jedzenia

